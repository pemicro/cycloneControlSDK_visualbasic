﻿Imports System.Runtime.InteropServices
Imports System.Threading

Public Class Form1
    'DLL management calls
    Declare Function version Lib "CycloneControlSDK_stdcall.dll" () As IntPtr

    'Port and connection management calls
    Declare Function queryNumberOfAutodetectedCyclones Lib "CycloneControlSDK_stdcall.dll" () As UInteger
    Declare Function queryInformationOfAutodetectedCyclone Lib "CycloneControlSDK_stdcall.dll" (ByVal autodetectIndex As UInteger, ByVal informationType As UInteger) As IntPtr
    Declare Sub enumerateAllPorts Lib "CycloneControlSDK_stdcall.dll" ()
    Declare Function connectToCyclone Lib "CycloneControlSDK_stdcall.dll" (ByVal nameIpOrPortIdentifier As String) As UInteger
    Declare Function connectToMultipleCyclones Lib "CycloneControlSDK_stdcall.dll" (ByVal nameIpOrPortIdentifierArray As String, ByVal cycloneHandleArrayPointer As IntPtr, ByVal numberOfCycloneOpensAttempted As IntPtr) As Boolean
    Declare Sub setLocalMachineIpNumber Lib "CycloneControlSDK_stdcall.dll" (ByVal ipNumber As String)
    Declare Sub disconnectFromAllCyclones Lib "CycloneControlSDK_stdcall.dll" ()

    'Cyclone control and management calls
    Declare Function startImageExecution Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal imageId As UInteger) As Boolean
    Declare Function startDynamicDataProgram Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal targetAddress As UInteger, ByVal dataLength As UShort, ByVal buffer As String) As Boolean
    Declare Function checkCycloneExecutionStatus Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger) As UInteger
    Declare Function dynamicReadBytes Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal targetAddress As UInteger, ByVal dataLength As UShort, ByVal buffer As String) As Boolean
    Declare Function resetCyclone Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal resetDelayInMs As UInteger) As Boolean
    Declare Function getFirmwareVersion Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger) As IntPtr

    'Error management calls
    Declare Function getNumberOfErrors Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger) As UInteger
    Declare Function getErrorCode Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal errorNum As UInteger) As Integer
    Declare Function getLastErrorAddr Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger) As UInteger
    Declare Function getDescriptionOfErrorCode Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal errorCode As Integer) As IntPtr

    'Image management calls
    Declare Function formatCycloneMemorySpace Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal selectedMediaType As UInteger) As Boolean
    Declare Function addCycloneImage Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal selectedMediaType As UInteger, ByVal replaceImageOfSameDescription As Boolean, ByVal aFile As String) As UInteger
    Declare Function eraseCycloneImage Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal imageId As UInteger) As Boolean
    Declare Function getImageDescription Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal imageId As UInteger) As IntPtr
    Declare Function compareImageInCycloneWithFile Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal aFile As String, ByVal imageId As UInteger) As Boolean
    Declare Function countCycloneImages Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger) As UInteger

    'Property calls
    Declare Function getPropertyValue Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal resourceOrImageId As UInteger, ByVal categoryName As String, ByVal propertyName As String) As IntPtr
    Declare Function setPropertyValue Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal resourceOrImageId As UInteger, ByVal categoryName As String, ByVal propertyName As String, ByVal newValue As String) As Boolean
    Declare Function getPropertyList Lib "CycloneControlSDK_stdcall.dll" (ByVal cycloneHandle As UInteger, ByVal resourceOrImageId As UInteger, ByVal categoryName As String) As IntPtr

    'Features calls
    Declare Function cycloneSpecialFeatures Lib "CycloneControlSDK_stdcall.dll" (ByVal featureNum As UInteger, ByVal setFeature As Boolean, ByVal paramValue1 As UInteger, ByVal paramValue2 As UInteger, ByVal paramValue3 As UInteger, ByVal paramReference1 As IntPtr, ByVal paramReference2 As IntPtr) As Boolean

    Private MEDIA_INTERNAL As UInteger = 1UI
    Private MEDIA_EXTERNAL As UInteger = 2UI

    'CATEGORY NAMES And THEIR PROPERTIES
    'A list Of properties supported by the Cyclone can
    'be retrieved With the getPropertyList() routine
    Private CycloneProperties As String = "cycloneProperties"
    Private selectCyclonePropertyType As String = "cycloneType"
    Private selectCyclonePropertyFirmwareVersion As String = "cycloneFirmwareVersion"
    Private selectCyclonePropertyCycloneLogicVersion As String = "cycloneLogicVersion"
    Private selectCyclonePropertyName As String = "cycloneName"
    Private selectCyclonePropertyNumberOfInternalImages As String = "numberOfInternalImages"
    Private selectCyclonePropertyNumberOfExternalImages As String = "numberOfExternalImages"
    Private selectCyclonePropertyNumberOfImages As String = "totalNumberOfImages"
    Private currentImageSelected As String = "currentImageSelected"

    Private NetworkProperties As String = "networkProperties"
    Private selectNetworkPropertyCycloneIPAddress As String = "cycloneIPAddress"
    Private selectNetworkPropertyCycloneNetmask As String = "cycloneNetworkMask"
    Private selectNetworkPropertyCycloneGateway As String = "cycloneNetworkGateway"
    Private selectNetworkPropertyCycloneDNS As String = "cycloneDNSAddress"

    Private ImageProperties As String = "imageProperties"
    Private selectImagePropertyName As String = "imageName"
    Private selectImagePropertyMediaType As String = "mediaType"
    Private selectImagePropertyUniqueId As String = "imageUniqueId"
    Private selectImagePropertyCRC32 As String = "imageCRC32"
    Private selectImagePropertyVoltageSettings As String = "imageVoltageSettings"
    Private selectImagePropertyFirstObjectCrc As String = "imageFirstObjectCrc"
    Private selectImagePropertyFirstDeviceCrc As String = "imageFirstDeviceCrc"
    Private selectImagePropertySerialNumberCount As String = "imageSerialNumberCount"
    Private selectImagePropertyGetSerialNumber As String = "imageSerialNumber" '# Append index In Decimal format, e.g. "imageSerialNumber1", "imageSerialNumber2"
    Private selectImageEncryptionStatus As String = "imageencryptionstatus"
    Private selectImageKeyID As String = "imagekeyid"
    Private selectImageKeyDescription As String = "imagekeydescription"

    Private TargetProperties As String = "targetProperties"
    Private selectTargetPropertyTargetVoltageReading As String = "targetVoltageReading"
    Private selectTargetPropertyTargetCurrentReading As String = "targetCurrentReading"
    Private selectTargetPropertyTargetObjectCrc As String = "targetObjectCrc"
    Private selectTargetPropertyTargetDeviceCrc As String = "targetDeviceCrc"

    'Commands
    Private PE_SET_FIRMWARE_UPDATE_PRINTF_CALLBACK As UInteger = &H58006001UI
    Private PE_CYCLONE_SDK_SET_FIRMWARE_UPDATE_MODE As UInteger = &H58006002UI
    Private PE_CYCLONE_SDK_ENABLE_DEBUG_OUT_FILE As UInteger = &H58006006UI

    Private CYCLONE_GET_IMAGE_DESCRIPTION_FROM_FILE As UInteger = &HA5001001UI
    Private CYCLONE_GET_IMAGE_CRC32_FROM_FILE As UInteger = &HA5001002UI
    Private CYCLONE_GET_IMAGE_SETTINGS_FROM_FILE As UInteger = &HA5001003UI
    Private CYCLONE_GET_IMAGE_COMMMAND_LINE_PARAMS_FROM_FILE As UInteger = &HA5001004UI
    Private CYCLONE_GET_IMAGE_SCRIPT_FILE_FROM_FILE As UInteger = &HA5001005UI

    Private CYCLONE_CHECK_IMAGE_FILE_ENCRYPTION_STATUS As UInteger = &HA5001018UI
    Private CYCLONE_GET_IMAGE_ENCRYPTION_KEY_UNIQUE_ID As UInteger = &HA5001019UI
    Private CYCLONE_GET_IMAGE_ENCRYPTION_KEY_DESCRIPTION As UInteger = &HA500101AUI
    Private CYCLONE_GET_IMAGE_ENCRYPTION_KEY_ORIGINAL_FILE As UInteger = &HA500101BUI
    Private CYCLONE_GET_IMAGE_ENCRYPTION_KEY_CURRENT_FILE As UInteger = &HA500101CUI
    Private CYCLONE_SET_IMAGE_ENCRYPTION_KEY_CURRENT_FILE As UInteger = &HA500101DUI

    Private PE_CYCLONE_GET_CYCLONE_SCREEN_BITMAP_BUFFER As UInteger = &HA5001101UI
    Private PE_CYCLONE_SEND_DISPLAY_TOUCH As UInteger = &HA5001102UI
    Private PE_CYCLONE_DOES_DISPLAY_NEED_UPDATE As UInteger = &HA5001103UI

    Private CYCLONE_TOGGLE_POWER_NO_DEBUG As UInteger = &HA5002001UI
    Private CYCLONE_SET_ACTIVE_SECURITY_CODE As UInteger = &HA5002002UI

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Handle As UInteger
        Dim ErrorCode As Integer

        Label1.Text = "DLL Version: " + Marshal.PtrToStringAnsi(version())
        enumerateAllPorts()
        Handle = connectToCyclone("USB1")
        Label2.Text = Marshal.PtrToStringAnsi(getImageDescription(Handle, 1))
        If Handle > 0 Then
            startImageExecution(Handle, 1)
            Do While checkCycloneExecutionStatus(Handle) = 1
                Thread.Sleep(2000)
            Loop
            If getNumberOfErrors(Handle) > 0 Then
                ErrorCode = getErrorCode(Handle, 1)
                Label3.Text = "Error Code: " + CStr(ErrorCode)
            Else
                Label3.Text = "Programming Successful"
            End If
        End If
        disconnectFromAllCyclones()

    End Sub
End Class